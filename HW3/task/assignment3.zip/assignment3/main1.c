int main(int argc, char **argv)
{
    wow_func_of_minilib();
    sin_func_of_minilib(1.0);
    hello_func_of_minilib();
    cos_func_of_minilib(2.0);
    wow_wow_func_of_minilib();
    return 0;
}
