void wow_wow_func_of_minilib()
{
    printf("WOW WOW minilib1 \n");
}


