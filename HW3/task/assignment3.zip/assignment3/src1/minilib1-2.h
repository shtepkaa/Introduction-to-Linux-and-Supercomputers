#include <stdio.h>

void wow_wow_func_of_minilib();
