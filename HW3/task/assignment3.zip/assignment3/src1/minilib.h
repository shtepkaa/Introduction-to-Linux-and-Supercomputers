#include <stdio.h>
#include <math.h>
void wow_func_of_minilib();

double sin_func_of_minilib(double x);

int hello_func_of_minilib();

double cos_func_of_minilib(double x);
