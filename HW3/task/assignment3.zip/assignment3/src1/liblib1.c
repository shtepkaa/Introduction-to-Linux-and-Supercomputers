void wow_func_of_minilib()
{
    printf("WOW minilib1 \n");
}


double sin_func_of_minilib(double x)
{
    return sin(x + M_PI);
}
