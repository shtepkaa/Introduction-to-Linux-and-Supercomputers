
void wow_func_of_minilib()
{
    printf("WOW WOW minilib2 \n");
}


double sin_func_of_minilib(double x)
{
    return 10.0 + sin(x + M_PI);
}
